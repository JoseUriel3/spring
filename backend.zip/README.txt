-----------------------------
INSTRUCCIONES
-----------------------------

Sólo se necesita abrir el proyecto en un IDE con soporte de JAVA EE (NetBeans, Eclipse, IntelliJ IDEA) y ejecutar el proyecto con un Servidor JAVA EE (GlassFish, Payara o TomCat)

-----------------------------

La url para probar el WS es la siguiente: http://localhost:8080/exercise1/mostrarInformacion

El puerto y configuración del server depende de la instalación del servidor de aplicaciones.

-----------------------------
José Uriel Murrieta García
Desarrollador Web / Java EE
+52 (231) 593 7077
uri.esgas@gmail.com
josuriel3@outlook.com
