package com.josuriel3.exercise1;

import com.josuriel3.exercise1.dto.UsuarioDto;
import com.josuriel3.exercise1.service.UsuarioService;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;
import java.util.List;
import org.springframework.beans.factory.annotation.Autowired;

@SpringBootApplication
@RestController
public class Exercise1Application {

    @Autowired
    private UsuarioService usuarioService;

    public Exercise1Application(UsuarioService usuarioService) {
        this.usuarioService = usuarioService;
    }

    public static void main(String[] args) {
        SpringApplication.run(Exercise1Application.class, args);
    }

    @GetMapping("/hello")
    public String hello(@RequestParam(value = "name", defaultValue = "José Uriel Murrieta García") String name) {
        return String.format("Hola mundo %s!", name);
    }

    @GetMapping("/mostrarInformacion")
    public List<UsuarioDto> mostrarInformacion() {
        return usuarioService.mostrarInformacion();
    }
}
