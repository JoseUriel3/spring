package com.josuriel3.exercise1.service;

import com.josuriel3.exercise1.dto.UsuarioDto;
import com.josuriel3.exercise1.repository.UsuarioRepo;
import com.josuriel3.exercise1.util.GestionArchivos;
import com.josuriel3.exercise1.util.GestionFechas;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.logging.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Service
public class UsuarioService {

    private static final Logger LOG = Logger.getLogger(UsuarioService.class.getName());

    @Autowired
    private UsuarioRepo usuarioRepo;

    public UsuarioService(UsuarioRepo usuarioRepo) {
        this.usuarioRepo = usuarioRepo;
    }

    public List<UsuarioDto> mostrarInformacion() {
        List<UsuarioDto> respuesta = new ArrayList<>();
        List<List<String>> archivo = GestionArchivos.consultarArchivoRecursos("datos/datos.txt");
        archivo.forEach(fila -> {
            respuesta.add(new UsuarioDto(
                    Integer.valueOf(fila.get(0)),
                    fila.get(1),
                    GestionFechas.obtenerFechaDeString(fila.get(2)),
                    GestionFechas.calcularTiempoEntreDosFechas(fila.get(2), GestionFechas.fechaDateString(new Date()))));
        });
        return respuesta;
    }

}
