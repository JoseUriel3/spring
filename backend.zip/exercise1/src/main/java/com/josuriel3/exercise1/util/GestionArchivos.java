package com.josuriel3.exercise1.util;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;
import java.util.logging.Level;
import java.util.logging.Logger;
import org.springframework.util.ResourceUtils;

public class GestionArchivos {

    private static final Logger LOG = Logger.getLogger(GestionArchivos.class.getName());

    public static List<List<String>> consultarArchivoRecursos(String ruta) {
        List<String> filas = leerArchivoRecursos(ruta);
        List<List<String>> respuesta = new ArrayList<>();
        filas.forEach(fila -> {

            String[] columnas = fila.split(",");

            List<String> columnasX = new ArrayList<>();
            for (String columna : columnas) {
                columnasX.add(columna);
            }
            respuesta.add(columnasX);

        });
        return respuesta;
    }

    public static List<String> leerArchivoRecursos(String ruta) {
        List<String> respuesta = new ArrayList<>();

        File archivo = null;
        FileReader fr = null;
        BufferedReader br = null;

        try {
            archivo = obtenerArchivoRecursos(ruta);
            fr = new FileReader(archivo);
            br = new BufferedReader(fr);

            String linea;
            while ((linea = br.readLine()) != null) {
                respuesta.add(linea);
                System.out.println(linea);
            }
        } catch (IOException e) {
            LOG.log(Level.SEVERE, "Error al leer el archivo {0}", ruta);
        } finally {
            try {
                if (null != fr) {
                    fr.close();
                }
            } catch (IOException e2) {
                LOG.log(Level.SEVERE, "Error al cerrar el archivo {0}", ruta);
            }
        }

        return respuesta;
    }

    public static File obtenerArchivoRecursos(String ruta) {
        try {
            return ResourceUtils.getFile("classpath:" + ruta);
        } catch (FileNotFoundException ex) {
            LOG.log(Level.SEVERE, "Error al leer el archivo");
            return null;
        }
    }

}
