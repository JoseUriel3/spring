package com.josuriel3.exercise1.util;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.TimeZone;
import java.util.logging.Level;
import java.util.logging.Logger;

public class GestionFechas {

    private static final Logger LOG = Logger.getLogger(GestionFechas.class.getName());

    public static Date obtenerFechaDeString(String fecha) {
        try {
            return fecha != null ? new SimpleDateFormat("dd/MM/yyyy HH:mm:ss").parse(fecha) : new Date();
        } catch (ParseException ex) {
            LOG.log(Level.SEVERE, "Error al tratar de convertir una fecha");
            return null;
        }
    }

    public static String fechaDateString(Date fecha) {
        SimpleDateFormat formatoFecha = new SimpleDateFormat("dd/MM/yyyy HH:mm:ss");
        formatoFecha.setTimeZone(TimeZone.getTimeZone("America/Mexico_City"));
        return fecha == null ? "" : formatoFecha.format(fecha);
    }

    public static String calcularTiempoEntreDosFechas(String fechaInicial, String fechaFinal) {

        java.util.GregorianCalendar jCal = new java.util.GregorianCalendar();
        java.util.GregorianCalendar jCal2 = new java.util.GregorianCalendar();

        jCal.set(Integer.parseInt(fechaInicial.substring(6, 10)), Integer.parseInt(fechaInicial.substring(3, 5)) - 1, Integer.parseInt(fechaInicial.substring(0, 2)), Integer.parseInt(fechaInicial.substring(11, 13)), Integer.parseInt(fechaInicial.substring(14, 16)), Integer.parseInt(fechaInicial.substring(17, 19)));
        jCal2.set(Integer.parseInt(fechaFinal.substring(6, 10)), Integer.parseInt(fechaFinal.substring(3, 5)) - 1, Integer.parseInt(fechaFinal.substring(0, 2)), Integer.parseInt(fechaFinal.substring(11, 13)), Integer.parseInt(fechaFinal.substring(14, 16)), Integer.parseInt(fechaFinal.substring(17, 19)));

        long diferencia = jCal2.getTime().getTime() - jCal.getTime().getTime();
        double minutos = diferencia / (1000 * 60);
        long horas = (long) (minutos / 60);
        long minuto = (long) (minutos % 60);
        long segundos = (long) diferencia % 1000;
        long dias = horas / 24;

        String[] mesesAnio = new String[12];
        mesesAnio[0] = "31";
        if (jCal.isLeapYear(jCal.YEAR)) {
            mesesAnio[1] = "29";
        } else {
            mesesAnio[1] = "28";
        }
        mesesAnio[2] = "31";
        mesesAnio[3] = "30";
        mesesAnio[4] = "31";
        mesesAnio[5] = "30";
        mesesAnio[6] = "31";
        mesesAnio[7] = "31";
        mesesAnio[8] = "30";
        mesesAnio[9] = "31";
        mesesAnio[10] = "30";
        mesesAnio[11] = "31";
        int diasRestantes = (int) dias;
        int totalMeses = 0;
        int mesActual = jCal.MONTH;
        for (int i = 0; i <= 11; i++) {
            if ((mesActual + 1) >= 12) {
                mesActual = i;
            }
            if ((diasRestantes - Integer.parseInt(mesesAnio[mesActual])) >= 0) {
                totalMeses++;
                diasRestantes = diasRestantes - Integer.parseInt(mesesAnio[mesActual]);
                mesActual++;
            } else {
                break;
            }
        }
        horas = horas % 24;
        String salida = "";
        if (totalMeses > 0) {
            if (totalMeses > 1) {
                salida = salida + String.valueOf(totalMeses) + " meses,  ";
            } else {
                salida = salida + String.valueOf(totalMeses) + " mes, ";
            }
        }
        if (diasRestantes > 0) {
            if (diasRestantes > 1) {
                salida = salida + String.valueOf(diasRestantes) + " días, ";
            } else {
                salida = salida + String.valueOf(diasRestantes) + " día, ";
            }
        }

        salida = salida + String.valueOf(horas) + " horas, " + String.valueOf(minuto) + " minutos, " + String.valueOf(segundos) + " segundos.";
        return salida;
    }

}
