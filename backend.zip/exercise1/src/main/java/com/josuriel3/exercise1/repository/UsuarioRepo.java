package com.josuriel3.exercise1.repository;

import java.util.logging.Logger;
import org.springframework.stereotype.Repository;

@Repository
public class UsuarioRepo {

    private static final Logger LOG = Logger.getLogger(UsuarioRepo.class.getName());

}
