-----------------------------
INSTRUCCIONES
-----------------------------

Sólo se necesita abrir el proyecto en un IDE con soporte de JAVA EE (NetBeans, Eclipse, IntelliJ IDEA) y ejecutar el proyecto con un Servidor JAVA EE (GlassFish, Payara o TomCat)

-----------------------------

La url para probar el WS es la siguiente: http://localhost:8080/exercise2

El puerto y configuración del server depende de la instalación del servidor de aplicaciones.
Si el puerto y configuración del server cambian, deberá modificarse la url de conexión en el archivo localizado en: exercise2\src\main\resources\static\js\usuarios.js

-----------------------------
José Uriel Murrieta García
Desarrollador Web / Java EE
+52 (231) 593 7077
uri.esgas@gmail.com
josuriel3@outlook.com
