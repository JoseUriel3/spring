$(document).ready(function () {
    $.ajax({
        url: "http://localhost:8080/exercise1/mostrarInformacion"
    }).then(function (data) {
        for (var i in data) {
            agregarColumnas(data[i]);
        }
    });
});

function agregarColumnas(object) {
    if ($("#usuarios tbody").length === 0) {
        $("#usuarios").append("<tbody></tbody>");
    }
    $("#usuarios tbody").append(construirColumnas(object));
}

function construirColumnas(object) {
    var ret = "<tr>"
            + "<td>" + object.id + "</td>"
            + "<td>" + object.nombre + "</td>"
            + "<td>" + object.fechaString + "</td>"
            + "<td>" + object.tiempo
            + "</td>" + "</tr>";
    return ret;
}