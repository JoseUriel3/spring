package com.josuriel3.exercise2.service;

import com.josuriel3.exercise2.bo.UsuarioBo;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import org.springframework.stereotype.Service;

@Service
public class UsuarioService {

    public List<UsuarioBo> listarUsuarios() {
        List<UsuarioBo> respuesta = new ArrayList<>();
        respuesta.add(new UsuarioBo(1, "Uriel", new Date(), "fecha", "tiempo"));
        return respuesta;
    }

}
